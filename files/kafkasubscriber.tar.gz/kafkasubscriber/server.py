# curl -i -H "Content-Type: application/json" -X PUT -d '{"topics":["topic1","topic2"]}' "http://localhost:5000/subscribe/172.28.0.28"
import os
import json
import urllib
from flask import Flask, jsonify, request, abort
from kafka import KafkaConsumer
#from multiprocessing import Process
from subprocess import Popen

app = Flask(__name__)

'''
bookkeeping = [
    {
        'endpoint': "172.28.0.28",
        'topics': 'topic1;topic2'
    },
]
'''

class configuration(object):

    def __init__(self):
        if (os.path.exists('/home/ubuntu/kafkasubscriber/kafkaip')):
            file = open('/home/ubuntu/kafkasubscriber/kafkaip', 'r')
            self.kafkaip = file.read()
            file.close()

    def configure(self, kafkaip):
        self.kafkaip = kafkaip

bookkeeping = []
running_consumers = {}
kafka_config = configuration()

def stop_consumer(endpoint):
    if endpoint in running_consumers:
        running_consumers[endpoint].terminate()
        returncode = running_consumers[endpoint].wait()
        del running_consumers[endpoint] 

@app.route('/subscribe', methods=['PUT'])
def subscribe():
    if not request.json:
        abort(400)
    if request.json['topics'] == []:
        stop_consumer(endpoint)
        return jsonify({'status': 200})

    endpoint = request.json['endpoint']

    config = [conf for conf in bookkeeping if conf['endpoint'] == endpoint]

    if len(config) == 0:
        conf = {
            'endpoint': endpoint,
            'topics': request.json['topics']
        }
        bookkeeping.append(conf)
        config.append(conf)
    else:
        config[0]['topics'] = request.json['topics']
        stop_consumer(endpoint)

    p = Popen(["python3", "consumer.py", endpoint, kafka_config.kafkaip, ' '.join(config[0]['topics'])])

    running_consumers[endpoint] = p
    
    return jsonify({'config': config[0]})

@app.route('/unsubscribe', methods=['DELETE'])
def unsubscribe():
    print('Unsubscribe DELETE request')
    if not request.json:
        abort(400)
    endpoint = request.json['endpoint']
    stop_consumer(endpoint)
    config = [conf for conf in bookkeeping if conf['endpoint'] == endpoint]
    if len(config) == 0:
        abort(400)
    bookkeeping.remove(config[0])
    return jsonify({'status': 200})

if __name__ == "__main__":
    app.run()