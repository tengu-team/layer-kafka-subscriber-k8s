#!/usr/bin/python
import sys
import json
import urllib.request
import datetime
from kafka import KafkaConsumer

def is_json(myjson):
  try:
    json_object = json.loads(myjson)
  except ValueError:
    return False
  return True

def main(argv):
    topics = tuple(filter(None, argv[3].split(' ')))
    endpoint = argv[1]
    kafkaip = argv[2]

    consumer = KafkaConsumer(bootstrap_servers=kafkaip, group_id=endpoint)
    consumer.subscribe(topics=topics)

    if not endpoint.startswith('http://'):
        endpoint = 'http://' + endpoint 

    for msg in consumer:
        msg_value = msg.value.decode('utf-8')
        msg_dict = {}
        msg_dict['topic'] = msg.topic
        msg_dict['subscriberTime'] = datetime.datetime.now().isoformat()
        if is_json(msg_value):
            msg_dict['message'] = json.loads(msg_value)
        else:
            msg_dict['message'] = msg_value
        params = json.dumps(msg_dict).encode('utf-8')
        req = urllib.request.Request(endpoint, data=params, headers={'content-type': 'application/json'})
        response = urllib.request.urlopen(req)

if __name__ == '__main__':
    #argv[0] = name
    #argv[1] = endpoint
    #argv[2] = kafkaip
    #argv[3] = topics 
    main(sys.argv)
